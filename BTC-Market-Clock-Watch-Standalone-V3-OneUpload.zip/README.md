# BTC Market Clock 手表独立版 V3.0

基于用户提供的 V1.4.2 源码。只有 Wear OS 模块，无手机 APK、无 Google Play Wearable Data Layer 依赖。使用原生 Java、AlarmManager、JobScheduler；不查询行情、不需要交易 API 密钥。

## 页面
- 主页：三地实时时间；阿根廷当地当天宏观重点、期权到期（含已发生事件），各自仅在有事件时显示；没有则完全隐藏。资金费率三次时间自然上移或下移。继续上滑查看当日美股交易时段，收盘后显示下一交易日，含纽约08:00盘前观察、正式开盘、下午观察、正式/提前收盘。全部保留三地日期时间。
- 设置：主页底部按钮或左滑进入，右滑或返回按钮退出。保留全部原有设置。盘前观察在未设置过时默认开启，已有明确设置值不改变。新增声音/振动渠道设置入口。删除未来重要事件长列表，但保留对应提醒。
- 提醒：新增统一高优先级通知渠道 market_alerts_v3，明确配置系统默认通知声及三段振动，并声明 VIBRATE 权限；测试提醒与正式提醒使用相同渠道。精确闹钟及重启恢复保留。重新安排时先更新有效闹钟，再取消过期计划；记录已发事件防重复；若重新安排时提醒时点已过而事件尚未发生，则安排补发。系统可能限制声音/振动、精确调度或同时到达通知，无法保证绝对准时。

## 独立安装
包名 `com.contractresearch.marketclock.standalone`，和旧手机/手表 App 不同，V1 手机/手表版不被覆盖。V2 独立版包名不变；同签名升级保留原有设置。若旧版也开着通知，建议关闭旧手表 App 的提醒避免重复。首次安装需授予通知及精确提醒权限。手表可使用 Wi-Fi/蜂窝或系统网络连接读取 BLS/BEA；没有网络时使用既有缓存或原源码有限的离线日历。系统可能延迟后台作业和未授权的闹钟。

## 日历范围
原源码的默认 Binance 8 小时结算不是所有合约的实际结算频率；NY 13:00 为观察点，并非重新开盘。BLS/BEA 使用原有官方 ICS 地址定期同步（系统约12小时调度）。FOMC 使用原源码预置 2026年12月及2027年日期，不自动获取后续变更；交易所特殊停市及提前收盘资料也沿用原源码，需要后续维护。CPI、非农、PCE、PPI、GDP 的日期以成功同步的机构公告为准。本版本未重新核验这些预置日期。

## GitHub 单 ZIP 编译
1. 创建一个新仓库 `BTC-Market-Clock-Watch-Standalone`，初始化 README。
2. 在仓库根目录上传整个 `BTC-Market-Clock-Watch-Standalone-V3-OneUpload.zip`，不解压。
3. 在仓库创建 `.github/workflows/android.yml`，将源码 ZIP 内同名文件（或单独提供的 workflow 文件）全文复制粘贴，提交。
4. Actions → Build BTC Watch Standalone APK → 成功运行 → Artifacts → `BTC-MarketClock-Watch-Standalone-Debug`。解压该构建产物得到 `wear-debug.apk`。

构建配置沿用 AGP 8.7.3、Gradle 8.10.2、Java 17、Android SDK 35，仅构建 :wear:assembleDebug。当前环境无 Android SDK/Gradle，未实际编译 APK、未实机测试。已用 JDK 解析全部 Java 源码语法，检查 XML/YAML，验证纯 Java 时间换算及提前时间；Android API 连接及实机通知声音/振动尚未验证。
