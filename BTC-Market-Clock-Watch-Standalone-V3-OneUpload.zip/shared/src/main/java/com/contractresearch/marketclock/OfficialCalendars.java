package com.contractresearch.marketclock;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Downloads only the public U.S. government ICS calendars. No API key, analytics or tracking. */
public final class OfficialCalendars {
    public static final String BLS="https://www.bls.gov/schedule/news_release/bls.ics";
    public static final String BEA="https://www.bea.gov/news/schedule/ics/online-calendar-subscription.ics";
    private OfficialCalendars() {}
    public static final class Result {
        public int bls,bea; public String errors="";
        public boolean success(){return bls>0||bea>0;}
    }
    public static void installJob(Context c) {
        try {
            JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if(js==null) return;
            JobInfo info=new JobInfo.Builder(24011,new ComponentName(c,CalendarJob.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(12L*60*60*1000).setPersisted(true).build();
            js.schedule(info);
        } catch(Exception e){ Log.w("BTCClock","Job schedule failed",e); }
    }
    public static Result refresh(Context c) {
        Result result=new Result();
        Map<String,Map<String,Long>> previous=new HashMap<>(), next=new HashMap<>();
        for(String t:new String[]{"cpi","nfp","ppi","pce","gdp"}) {previous.put(t,new HashMap<>());next.put(t,new HashMap<>());}
        try {
            JSONArray old=new JSONArray(Prefs.get(c).getString("macro_json","[]"));
            for(int i=0;i<old.length();i++) {
                JSONObject j=old.getJSONObject(i);String type=j.getString("type");
                if(previous.containsKey(type)) previous.get(type).put(j.getString("date"),j.getLong("ts"));
            }
        }catch(Exception ignored){}
        try { String raw=download(BLS); result.bls=parseIcs(raw,"bls",next); }
        catch(Exception e){ result.errors+="BLS: "+e.getMessage()+"; "; Log.w("BTCClock","BLS calendar",e); }
        try { String raw=download(BEA); result.bea=parseIcs(raw,"bea",next); }
        catch(Exception e){ result.errors+="BEA: "+e.getMessage()+"; "; Log.w("BTCClock","BEA calendar",e); }
        if(!result.success()) return result;
        JSONArray out=new JSONArray();
        for(String type:next.keySet()) {
            Map<String,Long> merged=new HashMap<>(previous.get(type));
            // Replace events of successfully retrieved feed; prevent stale canceled dates.
            boolean refreshed=(type.equals("cpi")||type.equals("nfp")||type.equals("ppi")) ? result.bls>0 : result.bea>0;
            if(refreshed) merged.clear();
            merged.putAll(next.get(type));
            for(Map.Entry<String,Long> e:merged.entrySet()) {
                if(e.getValue() < System.currentTimeMillis()-86400000L) continue;
                JSONObject j=new JSONObject();
                try {j.put("type",type);j.put("date",e.getKey());j.put("ts",e.getValue());out.put(j);}catch(Exception ignored){}
            }
        }
        Prefs.get(c).edit().putString("macro_json",out.toString())
                .putBoolean("bls_ok",result.bls>0 || Prefs.get(c).getBoolean("bls_ok",false))
                .putBoolean("bea_ok",result.bea>0 || Prefs.get(c).getBoolean("bea_ok",false))
                .putLong("last_sync",System.currentTimeMillis()).apply();
        Scheduler.plan(c);
        return result;
    }
    private static String download(String address) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(address).openConnection();
        conn.setConnectTimeout(9000);conn.setReadTimeout(9000);
        conn.setRequestProperty("Accept","text/calendar,text/plain,*/*");
        conn.setRequestProperty("User-Agent","BTC-MarketClock/1.0 (+offline-calendar-reminders)");
        try {
            if(conn.getResponseCode()!=200) throw new IOException("HTTP "+conn.getResponseCode());
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                byte[] b=new byte[8192];int n;int count=0;
                while((n=in.read(b))!=-1){count+=n;if(count>3_000_000)throw new IOException("ICS too large");out.write(b,0,n);}
                return out.toString(StandardCharsets.UTF_8.name());
            }
        }finally {conn.disconnect();}
    }
    static int parseIcs(String raw,String feed,Map<String,Map<String,Long>> data) {
        String normalized=raw.replace("\r\n","\n").replace('\r','\n');
        normalized=normalized.replaceAll("\n[ \\t]",""); // RFC 5545 folded lines
        boolean inside=false;String summary="",dt="",dtPrefix="";int added=0;
        for(String line:normalized.split("\n")) {
            if(line.equals("BEGIN:VEVENT")){inside=true;summary="";dt="";dtPrefix="";continue;}
            if(line.equals("END:VEVENT")){
                if(inside) {
                    String type=classify(summary,feed);
                    if(type!=null && !dt.isEmpty()) try {
                        Instant at=parseStart(dt,dtPrefix);
                        if(at.isAfter(Instant.now().minus(Duration.ofDays(1))) && at.isBefore(Instant.now().plus(Duration.ofDays(460)))) {
                            String date=at.atZone(MarketCalendar.NEW_YORK).toLocalDate().toString();
                            data.get(type).put(date,at.toEpochMilli());added++;
                        }
                    }catch(Exception e){Log.w("BTCClock","ICS event date: "+dt,e);}
                }
                inside=false;continue;
            }
            if(!inside)continue;
            int colon=line.indexOf(':'); if(colon<0)continue;
            String key=line.substring(0,colon).toUpperCase(Locale.US),value=line.substring(colon+1);
            if(key.startsWith("SUMMARY")) summary=value.replace("\\,",",").trim();
            if(key.startsWith("DTSTART")){dt=value.trim();dtPrefix=key;}
        }
        return added;
    }
    static String classify(String s,String feed) {
        String t=s.toLowerCase(Locale.US);
        if(feed.equals("bls")) {
            if(t.contains("consumer price index"))return "cpi";
            if(t.contains("employment situation"))return "nfp";
            if(t.contains("producer price index"))return "ppi";
        } else {
            if(t.contains("personal income and outlays"))return "pce";
            if(t.contains("gross domestic product") && (t.contains("advance")||t.contains("first estimate")))return "gdp";
        }
        return null;
    }
    static Instant parseStart(String s,String prefix) {
        if(s.length()==8) return LocalDate.parse(s,DateTimeFormatter.BASIC_ISO_DATE).atTime(8,30).atZone(MarketCalendar.NEW_YORK).toInstant();
        if(s.endsWith("Z")) {
            String core=s.substring(0,s.length()-1);
            return parseLocal(core).toInstant(ZoneOffset.UTC);
        }
        ZoneId zone=MarketCalendar.NEW_YORK;
        int p=prefix.indexOf("TZID=");
        if(p>=0) {
            String zoneName=prefix.substring(p+5).split(";")[0];
            try{zone=ZoneId.of(zoneName);}catch(Exception ignored){}
        }
        return parseLocal(s).atZone(zone).toInstant();
    }
    static LocalDateTime parseLocal(String s) {
        if(s.length()==13) return LocalDateTime.parse(s,DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmm",Locale.US));
        return LocalDateTime.parse(s,DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss",Locale.US));
    }
}
