package com.contractresearch.marketclock;

import android.content.Context;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

public final class MarketCalendar {
    private static final ZoneId NY=ClockZones.NEW_YORK, UTC=ZoneOffset.UTC;
    public static final ZoneId ARGENTINA=ClockZones.ARGENTINA, BEIJING=ClockZones.BEIJING, NEW_YORK=NY;
    private MarketCalendar() {}

    public static ArrayList<MarketEvent> all(Context c,Instant start,int days) {
        Instant end=start.plus(Duration.ofDays(days));
        ArrayList<MarketEvent> list=new ArrayList<>();
        LocalDate utcStart=start.atZone(UTC).toLocalDate().minusDays(1);
        LocalDate nyStart=start.atZone(NY).toLocalDate().minusDays(1);
        for(int i=0;i<days+3;i++) {
            LocalDate u=utcStart.plusDays(i);
            for(int h:new int[]{0,8,16}) add(list,new MarketEvent("funding","Binance 8小时资金费率","默认周期；请核实具体合约",u.atTime(h,0).atZone(UTC).toInstant(),false),start,end);
            if (u.getDayOfWeek()==DayOfWeek.FRIDAY && u.equals(u.with(TemporalAdjusters.lastInMonth(DayOfWeek.FRIDAY)))) {
                add(list,new MarketEvent("expiry",u.getMonthValue()%3==0?"BTC 季度期权到期":"BTC 月度期权到期","Deribit 月末周五 08:00 UTC",u.atTime(8,0).atZone(UTC).toInstant(),true),start,end);
            }
            LocalDate n=nyStart.plusDays(i);
            if (nyseOpen(n)) {
                int close=earlyClose(n)?13:16;
                add(list,new MarketEvent("nyse_pre","美股盘前观察","非正式开盘",n.atTime(8,0).atZone(NY).toInstant(),false),start,end);
                add(list,new MarketEvent("nyse_open","美股正式开盘","NYSE 09:30 纽约时间",n.atTime(9,30).atZone(NY).toInstant(),false),start,end);
                if (close>13) add(list,new MarketEvent("nyse_afternoon","美股下午观察","13:00 观察点，非二次开盘",n.atTime(13,0).atZone(NY).toInstant(),false),start,end);
                add(list,new MarketEvent("nyse_close",close==13?"美股提前收盘":"美股正式收盘",close==13?"NYSE 提前收盘 13:00":"NYSE 16:00 纽约时间",n.atTime(close,0).atZone(NY).toInstant(),false),start,end);
            }
        }
        // Latest verified FOMC decision dates: October 2027 is policy strategy only, not a rate decision.
        for(String ds:new String[]{"2026-12-09", "2027-01-27", "2027-03-17", "2027-04-28", "2027-06-09", "2027-07-28", "2027-09-15", "2027-11-17"}) {
            LocalDate d=LocalDate.parse(ds);
            add(list,new MarketEvent("fomc","FOMC 利率决议","美联储暂定日历；14:00 ET",d.atTime(14,0).atZone(NY).toInstant(),true),start,end);
        }
        // Verified BLS dates are a limited offline fallback; online calendar updates override duplicates.
        if(!Prefs.get(c).getBoolean("bls_ok",false)) offline(list,start,end,"cpi","美国 CPI 数据",new String[]{"2026-12-10","2027-01-13","2027-02-11","2027-03-10","2027-04-13","2027-05-12","2027-06-10","2027-07-14","2027-08-11","2027-09-14","2027-10-14","2027-11-10","2027-12-10"});
        if(!Prefs.get(c).getBoolean("bls_ok",false)) offline(list,start,end,"nfp","美国非农就业报告",new String[]{"2026-12-04","2027-01-08","2027-02-05","2027-03-05","2027-04-02","2027-05-07","2027-06-04","2027-07-02","2027-08-06","2027-09-03","2027-10-08","2027-11-05","2027-12-03"});
        if(!Prefs.get(c).getBoolean("bea_ok",false)) offline(list,start,end,"pce","美国 PCE 通胀数据",new String[]{"2026-11-25","2026-12-23"});
        // Official feeds take precedence over the offline fallbacks by event type + NY local date.
        try {
            String raw=Prefs.get(c).getString("macro_json","[]");
            JSONArray a=new JSONArray(raw);
            for(int i=0;i<a.length();i++) {
                JSONObject j=a.getJSONObject(i);
                String type=j.getString("type"); Instant at=Instant.ofEpochMilli(j.getLong("ts"));
                if(at.isBefore(start)||!at.isBefore(end)) continue;
                LocalDate day=at.atZone(NY).toLocalDate();
                list.removeIf(e -> e.type.equals(type) && e.at.atZone(NY).toLocalDate().equals(day));
                add(list,new MarketEvent(type,title(type),"官方数据日历（定期同步）",at,high(type)),start,end);
            }
        } catch(Exception e) { Log.w("BTCClock","Calendar cache parse error",e); }
        Collections.sort(list);
        return list;
    }
    private static boolean high(String t){ return t.equals("fomc")||t.equals("cpi")||t.equals("nfp")||t.equals("pce"); }
    public static String title(String t) {
        switch(t) { case "cpi":return "美国 CPI 数据"; case "nfp":return "美国非农就业报告"; case "ppi":return "美国 PPI 数据"; case "pce":return "美国 PCE 通胀数据"; case "gdp":return "美国 GDP 首次预估"; default:return t; }
    }
    private static void offline(ArrayList<MarketEvent> out,Instant start,Instant end,String type,String title,String[] dates) {
        for(String s:dates) add(out,new MarketEvent(type,title,"官方日历预置（可联网更新）",LocalDate.parse(s).atTime(8,30).atZone(NY).toInstant(),true),start,end);
    }
    private static void add(ArrayList<MarketEvent> out,MarketEvent e,Instant start,Instant end) { if(!e.at.isBefore(start)&&e.at.isBefore(end)) out.add(e); }
    private static boolean nyseOpen(LocalDate d){
        DayOfWeek wd=d.getDayOfWeek(); if(wd==DayOfWeek.SATURDAY||wd==DayOfWeek.SUNDAY) return false;
        int y=d.getYear();
        ArrayList<LocalDate> h=new ArrayList<>();
        h.add(observed(LocalDate.of(y,1,1)));
        h.add(LocalDate.of(y,1,1).with(TemporalAdjusters.dayOfWeekInMonth(3,DayOfWeek.MONDAY)));
        h.add(LocalDate.of(y,2,1).with(TemporalAdjusters.dayOfWeekInMonth(3,DayOfWeek.MONDAY)));
        h.add(easter(y).minusDays(2));
        h.add(LocalDate.of(y,5,1).with(TemporalAdjusters.lastInMonth(DayOfWeek.MONDAY)));
        h.add(observed(LocalDate.of(y,6,19)));
        h.add(observed(LocalDate.of(y,7,4)));
        h.add(LocalDate.of(y,9,1).with(TemporalAdjusters.firstInMonth(DayOfWeek.MONDAY)));
        h.add(LocalDate.of(y,11,1).with(TemporalAdjusters.dayOfWeekInMonth(4,DayOfWeek.THURSDAY)));
        h.add(observed(LocalDate.of(y,12,25)));
        // Jan 1 observed on preceding Dec 31 could affect prior year.
        h.add(observed(LocalDate.of(y+1,1,1)));
        return !h.contains(d);
    }
    private static LocalDate observed(LocalDate d) {
        if(d.getDayOfWeek()==DayOfWeek.SATURDAY) return d.minusDays(1);
        if(d.getDayOfWeek()==DayOfWeek.SUNDAY) return d.plusDays(1);
        return d;
    }
    private static LocalDate easter(int y) { // Gregorian computus, for Good Friday NYSE closure.
        int a=y%19,b=y/100,c=y%100,d=b/4,e=b%4,f=(b+8)/25,g=(b-f+1)/3,h=(19*a+b-d-g+15)%30,i=c/4,k=c%4,l=(32+2*e+2*i-h-k)%7,m=(a+11*h+22*l)/451,month=(h+l-7*m+114)/31,day=((h+l-7*m+114)%31)+1;
        return LocalDate.of(y,month,day);
    }
    private static boolean earlyClose(LocalDate d) {
        return d.toString().equals("2026-11-27")||d.toString().equals("2026-12-24")||d.toString().equals("2027-11-26")||d.toString().equals("2028-07-03")||d.toString().equals("2028-11-24");
    }
    public static String format(Instant at,ZoneId z) {
        return ClockZones.label(at,z);
    }
    public static String countdown(Instant at,Instant now) {
        long mins=Math.max(0,Duration.between(now,at).toMinutes());
        if(mins<60)return mins+"分钟";
        long h=mins/60, m=mins%60;
        if(h<48)return h+"小时"+m+"分";
        return (h/24)+"天"+(h%24)+"小时";
    }
}
