package com.contractresearch.marketclock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/** Standalone native Wear UI. Two pages, each vertically scrollable. */
public class MainActivity extends Activity {
    private static final int BG=0xff091119,CARD=0xff13212b,CARD2=0xff192c36,
        WHITE=0xffe8f6f5,SOFT=0xffa3b8bc,MINT=0xff39deca,ORANGE=0xffffc18c;
    private static final ZoneId[] ZONES={ClockZones.ARGENTINA,ClockZones.BEIJING,ClockZones.NEW_YORK};
    private static final String[] NAMES={"阿根廷","北京","纽约"};
    private static final DateTimeFormatter DATE=DateTimeFormatter.ofPattern("MM/dd",Locale.US), TIME=DateTimeFormatter.ofPattern("HH:mm",Locale.US);
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final TextView[] clockDates=new TextView[3],clockTimes=new TextView[3];
    private ScrollView scroll;
    private LinearLayout root;
    private boolean settingsPage, syncing, lastExact, lastAlertReady, resumed;
    private LocalDate homeDate;
    private Instant sessionClose;
    private long shownSync;
    private int homeScroll, settingsScroll;
    private float touchX,touchY;
    private final Runnable ticker=new Runnable(){public void run(){
        if(!settingsPage){Instant now=Instant.now();
            if(!now.atZone(ZONES[0]).toLocalDate().equals(homeDate) || (sessionClose!=null && !now.isBefore(sessionClose)) || shownSync!=Prefs.get(MainActivity.this).getLong("last_sync",0)){render(true);}else updateClocks();}
        handler.postDelayed(this,1000);
    }};
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(BG);getWindow().setStatusBarColor(BG);
        if(b!=null){settingsPage=b.getBoolean("settings");homeScroll=b.getInt("homeScroll");settingsScroll=b.getInt("settingsScroll");}
        lastExact=Scheduler.exactAllowed(this);
        AlarmReceiver.ensureChannel(this);lastAlertReady=AlarmReceiver.channelReady(this);
        OfficialCalendars.installJob(this);Scheduler.plan(this);
        render(false);requestNotificationPermission();
        if(Prefs.get(this).getLong("last_sync",0)==0) syncCalendar(false);
    }
    @Override public void onSaveInstanceState(Bundle out){saveScroll();out.putBoolean("settings",settingsPage);out.putInt("homeScroll",homeScroll);out.putInt("settingsScroll",settingsScroll);super.onSaveInstanceState(out);}
    @Override public void onResume(){super.onResume();resumed=true;
        boolean exact=Scheduler.exactAllowed(this),ready=AlarmReceiver.channelReady(this);if(exact!=lastExact||ready!=lastAlertReady){lastExact=exact;lastAlertReady=ready;Scheduler.plan(this);}
        render(true);handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override public void onPause(){resumed=false;handler.removeCallbacks(ticker);super.onPause();}
    @Override public void onRequestPermissionsResult(int req,String[] perms,int[] results){super.onRequestPermissionsResult(req,perms,results);if(req==88){Scheduler.plan(this);render(true);}}
    @Override public void onBackPressed(){if(settingsPage)switchPage(false);else super.onBackPressed();}
    @Override public boolean dispatchTouchEvent(MotionEvent e){
        if(e.getActionMasked()==MotionEvent.ACTION_DOWN){touchX=e.getX();touchY=e.getY();}
        if(e.getActionMasked()==MotionEvent.ACTION_UP){float dx=e.getX()-touchX,dy=e.getY()-touchY;
            if(Math.abs(dx)>dp(55)&&Math.abs(dx)>Math.abs(dy)*1.6f&&((dx<0&&!settingsPage)||(dx>0&&settingsPage))){
                MotionEvent cancel=MotionEvent.obtain(e);cancel.setAction(MotionEvent.ACTION_CANCEL);super.dispatchTouchEvent(cancel);cancel.recycle();switchPage(!settingsPage);return true;}}
        return super.dispatchTouchEvent(e);
    }
    private void saveScroll(){if(scroll!=null){if(settingsPage)settingsScroll=scroll.getScrollY();else homeScroll=scroll.getScrollY();}}
    private void switchPage(boolean settings){if(settings==settingsPage)return;saveScroll();settingsPage=settings;render(false);}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(radius));return g;}
    private TextView text(String s,float size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setIncludeFontPadding(false);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout col(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private void add(LinearLayout p,View v,int gap){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(gap);p.addView(v,lp);}
    private void center(LinearLayout p,String s,float size,int color,boolean bold,int gap){TextView t=text(s,size,color,bold);t.setGravity(Gravity.CENTER);add(p,t,gap);}
    private void weight(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(0,-2,1));}
    private void line(LinearLayout p){View v=new View(this);v.setBackgroundColor(0xff29404a);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));lp.topMargin=dp(3);lp.bottomMargin=dp(3);p.addView(v,lp);}
    private Button button(String label,boolean selected){Button b=new Button(this);b.setText(label);b.setTextSize(13);b.setAllCaps(false);b.setTextColor(selected?BG:WHITE);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(shape(selected?MINT:CARD2,12));b.setMinHeight(dp(44));b.setMinimumHeight(dp(44));b.setMinWidth(0);b.setMinimumWidth(0);b.setPadding(dp(4),dp(6),dp(4),dp(6));return b;}
    private void action(LinearLayout p,String label,Runnable run){Button b=button(label,false);b.setOnClickListener(v->run.run());add(p,b,6);}
    private LinearLayout panel(){LinearLayout p=col();p.setBackground(shape(CARD,14));p.setPadding(dp(5),dp(7),dp(5),dp(7));return p;}
    private void render(boolean retain){
        if(isFinishing()||isDestroyed())return;if(retain)saveScroll();
        scroll=new ScrollView(this);scroll.setBackgroundColor(BG);scroll.setFillViewport(true);scroll.setVerticalScrollBarEnabled(false);
        root=col();root.setGravity(Gravity.CENTER_HORIZONTAL);
        boolean round=getResources().getConfiguration().isScreenRound();
        root.setPadding(dp(round?19:10),dp(round?31:8),dp(round?19:10),dp(round?34:12));
        scroll.addView(root,new ScrollView.LayoutParams(-1,-2));setContentView(scroll);
        if(settingsPage)buildSettings();else buildHome();
        final ScrollView current=scroll;final int y=settingsPage?settingsScroll:homeScroll;current.post(()->{if(scroll==current)current.scrollTo(0,y);});
    }
    private void buildHome(){
        Instant now=Instant.now();homeDate=now.atZone(ZONES[0]).toLocalDate();shownSync=Prefs.get(this).getLong("last_sync",0);
        center(root,"BTC MARKET CLOCK",13,MINT,true,2);
        center(root,"阿根廷为提醒基准",11,SOFT,false,5);
        LinearLayout clocks=panel(),r=row();
        for(int i=0;i<3;i++){LinearLayout c=col();center(c,NAMES[i],11,i==0?MINT:SOFT,true,2);
            clockTimes[i]=text("",17,i==0?MINT:WHITE,true);clockTimes[i].setGravity(Gravity.CENTER);add(c,clockTimes[i],1);
            clockDates[i]=text("",11,SOFT,false);clockDates[i].setGravity(Gravity.CENTER);add(c,clockDates[i],0);weight(r,c);}
        add(clocks,r,0);add(root,clocks,7);updateClocks();
        buildTodayEvents();
        center(root,"资金费率 · 每日3次",14,MINT,true,2);
        center(root,homeDate.toString()+" · 阿根廷日期",11,SOFT,false,3);
        LinearLayout funding=panel();zoneHeader(funding);
        for(int h:new int[]{5,13,21}){if(h!=5)line(funding);timeRow(funding,ClockZones.fundingOnArgentinaDate(homeDate,h));}
        add(root,funding,8);
        // Keep the complete current NY trading session until close; then show the next one.
        Instant nyMidnight=now.atZone(ZONES[2]).toLocalDate().atStartOfDay(ZONES[2]).toInstant();
        List<MarketEvent> future=MarketCalendar.all(this,nyMidnight,14);
        sessionClose=null;for(MarketEvent e:future)if(e.type.equals("nyse_close")&&e.at.isAfter(now)){sessionClose=e.at;break;}
        if(sessionClose==null){center(root,"美股 · 暂无交易日资料",12,SOFT,false,6);}else{
            LocalDate session=sessionClose.atZone(ZONES[2]).toLocalDate();
            center(root,session.equals(now.atZone(ZONES[2]).toLocalDate())?"今日美股交易日":"下一美股交易日",14,MINT,true,2);
            center(root,session+" · 纽约日期",11,SOFT,false,3);
            LinearLayout stocks=panel();zoneHeader(stocks);
            boolean afternoon=false,first=true;
            for(MarketEvent e:future){if(!e.at.atZone(ZONES[2]).toLocalDate().equals(session))continue;
                String label;
                switch(e.type){case "nyse_pre":label="盘前观察";break;case "nyse_open":label="正式开盘";break;case "nyse_afternoon":label="下午观察";afternoon=true;break;case "nyse_close":label=e.title.contains("提前")?"提前收盘":"正式收盘";break;default:continue;}
                if(!first)line(stocks);first=false;center(stocks,label,12,WHITE,true,2);timeRow(stocks,e.at);
            }
            if(!afternoon)center(stocks,"提前收盘日无下午观察",10,SOFT,false,0);
            add(root,stocks,7);
        }
        action(root,"提醒设置  ↓",()->switchPage(true));
        center(root,"左滑也可进入设置",11,SOFT,false,0);
    }
    private void buildTodayEvents(){
        // Argentina's local date, including already published events. No empty placeholders.
        Instant start=homeDate.atStartOfDay(ZONES[0]).toInstant();
        Instant end=homeDate.plusDays(1).atStartOfDay(ZONES[0]).toInstant();
        LinearLayout macro=null,expiry=null;
        for(MarketEvent e:MarketCalendar.all(this,start,2)){
            if(!e.at.isBefore(end)||e.type.equals("funding")||e.type.startsWith("nyse"))continue;
            if(!Arrays.asList("expiry","fomc","cpi","nfp","pce","ppi","gdp").contains(e.type))continue;
            LinearLayout p;
            if(e.type.equals("expiry")){if(expiry==null){expiry=panel();zoneHeader(expiry);}else line(expiry);p=expiry;}
            else{if(macro==null){macro=panel();zoneHeader(macro);}else line(macro);p=macro;}
            center(p,e.title,13,ORANGE,true,2);timeRow(p,e.at);
            boolean on=Prefs.notificationsEnabled(this)&&Prefs.enabled(this,e.type);
            center(p,on?"提前"+Prefs.lead(this,e.type,e.at)+"分钟提醒":"提醒已关闭",11,SOFT,false,2);
        }
        if(macro!=null){center(root,"今日宏观重点",14,ORANGE,true,3);add(root,macro,6);}
        if(expiry!=null){center(root,"今日期权到期",14,ORANGE,true,3);add(root,expiry,6);}
    }
    private void zoneHeader(LinearLayout p){LinearLayout r=row();for(int i=0;i<3;i++){TextView t=text(NAMES[i],11,i==0?MINT:SOFT,true);t.setGravity(Gravity.CENTER);weight(r,t);}add(p,r,3);}
    private void timeRow(LinearLayout p,Instant at){LinearLayout r=row();for(int i=0;i<3;i++){
        ZonedDateTime z=at.atZone(ZONES[i]);LinearLayout c=col();center(c,z.format(TIME),16,i==0?MINT:WHITE,true,1);center(c,z.format(DATE),10,SOFT,false,0);weight(r,c);}add(p,r,0);}
    private void updateClocks(){Instant now=Instant.now();for(int i=0;i<3;i++){ZonedDateTime z=now.atZone(ZONES[i]);if(clockTimes[i]!=null){String time=z.format(TIME),date=z.format(DATE);if(!time.contentEquals(clockTimes[i].getText()))clockTimes[i].setText(time);if(!date.contentEquals(clockDates[i].getText()))clockDates[i].setText(date);}}}
    private void buildSettings(){
        center(root,"提醒设置",17,MINT,true,5);
        action(root,"返回主页  ↑",()->switchPage(false));
        center(root,"以阿根廷时间为准",12,SOFT,false,6);
        center(root,"全部事件统一提前",12,WHITE,true,3);
        pair(root,"15分钟","30分钟",0,()->{Prefs.setLead(this,15);changed();},()->{Prefs.setLead(this,30);changed();},true);
        toggle(root,"notify_here","本机接收通知",true);
        heading("资金费率");toggle(root,"funding","每天3次",true);
        for(int h:new int[]{5,13,21}){center(root,String.format(Locale.US,"阿根廷 %02d:00 结算",h),13,MINT,true,3);leads(root,String.format(Locale.US,"funding_%02d",h),Prefs.enabled(this,"funding"));}
        heading("美股（纽约时间）");
        option("nyse_open","09:30 开盘",true);option("nyse_afternoon","13:00 下午观察",true);option("nyse_close","16:00 收盘",true);option("nyse_pre","08:00 盘前观察",true);
        heading("期权及宏观数据");
        option("expiry","BTC 月度期权到期",true);option("fomc","FOMC 利率决议",true);option("cpi","CPI 通胀数据",true);option("nfp","非农就业数据",true);option("pce","PCE 通胀数据",true);option("ppi","PPI 通胀数据（可选）",false);option("gdp","GDP 首次预估（可选）",false);
        heading("日历及通知权限");
        Button sync=button(syncing?"正在同步…":"联网同步 BLS / BEA\n官方数据日历",false);sync.setEnabled(!syncing);sync.setOnClickListener(v->syncCalendar(true));add(root,sync,6);
        action(root,"测试本机提醒\n约10秒后",()->{if(!hasNotificationPermission()){requestNotificationPermission();Toast.makeText(this,"授权后请再次测试",Toast.LENGTH_SHORT).show();}else{Scheduler.test(this);Toast.makeText(this,"测试提醒已安排",Toast.LENGTH_SHORT).show();}});
        action(root,Scheduler.exactAllowed(this)?"精确提醒权限：已允许":"开启精确提醒权限",()->{
            if(Build.VERSION.SDK_INT>=31&&!Scheduler.exactAllowed(this)){try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){Toast.makeText(this,"请在系统设置允许闹钟与提醒",Toast.LENGTH_LONG).show();}}
            else Toast.makeText(this,"精确提醒已启用",Toast.LENGTH_SHORT).show();});
        action(root,AlarmReceiver.channelReady(this)?"声音 / 振动：检查设置":"声音 / 振动：需检查",()->{
            AlarmReceiver.ensureChannel(this);
            try{startActivity(new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,AlarmReceiver.CHANNEL));}
            catch(Exception e){startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));}
        });
        if(!hasNotificationPermission())action(root,"通知权限：未允许",()->requestNotificationPermission());
        long synced=Prefs.get(this).getLong("last_sync",0);
        center(root,synced==0?"宏观日历：尚未联网同步":"宏观日历同步（阿根廷）\n"+MarketCalendar.format(Instant.ofEpochMilli(synced),ZONES[0]),11,SOFT,false,6);
        center(root,"关闭精确提醒权限或限制后台运行时，Android 可能延迟通知。手表独立运行，无需手机同步。美国数据发布时间可能变更，以发布机构公告为准。资金费率为默认8小时周期，不代表全部合约。",11,SOFT,false,8);
        action(root,"返回主页  ↑",()->switchPage(false));
        center(root,"右滑也可返回主页",11,SOFT,false,0);
    }
    private void heading(String title){line(root);center(root,title,14,MINT,true,4);}
    private void option(String key,String label,boolean def){toggle(root,key,label,def);leads(root,key,Prefs.enabled(this,key));}
    private void toggle(LinearLayout p,String key,String label,boolean def){Switch sw=new Switch(this);sw.setText(label);sw.setTextSize(13);sw.setTextColor(WHITE);sw.setMinHeight(dp(44));sw.setPadding(dp(2),dp(3),dp(2),dp(3));sw.setChecked(Prefs.get(this).getBoolean(key,def));sw.setOnCheckedChangeListener((v,checked)->{Prefs.setEnabled(this,key,checked);changed();});add(p,sw,2);}
    private void leads(LinearLayout p,String key,boolean enabled){pair(p,"提前15分","提前30分",Prefs.lead(this,key),()->{Prefs.setTypeLead(this,key,15);changed();},()->{Prefs.setTypeLead(this,key,30);changed();},enabled);}
    private void pair(LinearLayout p,String a,String b,int selected,Runnable first,Runnable second,boolean enabled){LinearLayout r=row();String[] labels={a,b};Runnable[] runs={first,second};for(int i=0;i<2;i++){boolean checked=selected==(i==0?15:30);Button v=button((checked?"✓ ":"")+labels[i],checked);v.setEnabled(enabled);v.setAlpha(enabled?1f:.45f);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);if(i==0)lp.rightMargin=dp(4);r.addView(v,lp);final Runnable run=runs[i];v.setOnClickListener(w->run.run());}add(p,r,5);}
    private void changed(){Scheduler.plan(this);render(true);}
    private void syncCalendar(boolean manual){if(syncing)return;syncing=true;if(settingsPage)render(true);new Thread(()->{OfficialCalendars.Result result=OfficialCalendars.refresh(getApplicationContext());runOnUiThread(()->{syncing=false;if(isFinishing()||isDestroyed())return;if(manual)Toast.makeText(this,result.success()?"已更新：BLS "+result.bls+"，BEA "+result.bea:"官方日历更新失败，请检查网络",Toast.LENGTH_LONG).show();if(resumed)render(true);});},"OfficialCalendarSync").start();}
    private boolean hasNotificationPermission(){return Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;}
    private void requestNotificationPermission(){if(!hasNotificationPermission())requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},88);}
}
