package com.contractresearch.marketclock;

import java.time.Instant;

public final class MarketEvent implements Comparable<MarketEvent> {
    public final String type, title, detail;
    public final Instant at;
    public final boolean high;
    public MarketEvent(String type, String title, String detail, Instant at, boolean high) {
        this.type=type; this.title=title; this.detail=detail; this.at=at; this.high=high;
    }
    public String key() { return type+"_"+at.getEpochSecond(); }
    @Override public int compareTo(MarketEvent e) { return this.at.compareTo(e.at); }
}
