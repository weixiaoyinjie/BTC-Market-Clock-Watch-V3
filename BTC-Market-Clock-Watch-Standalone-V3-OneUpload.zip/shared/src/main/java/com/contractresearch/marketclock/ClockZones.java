package com.contractresearch.marketclock;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** All UI/reminder clock labels are explicitly zoned; never inferred from device timezone. */
public final class ClockZones {
    public static final ZoneId ARGENTINA = ZoneId.of("America/Argentina/Buenos_Aires");
    public static final ZoneId BEIJING = ZoneId.of("Asia/Shanghai");
    public static final ZoneId NEW_YORK = ZoneId.of("America/New_York");
    private static final DateTimeFormatter LABEL = DateTimeFormatter.ofPattern("MM/dd EEE HH:mm",Locale.CHINA);
    private static final DateTimeFormatter SHORT = DateTimeFormatter.ofPattern("MM/dd HH:mm",Locale.CHINA);
    private ClockZones(){}

    public static String label(Instant at,ZoneId zone){return at.atZone(zone).format(LABEL);}
    public static String shortLabel(Instant at,ZoneId zone){return at.atZone(zone).format(SHORT);}
    public static String threeZoneLabel(Instant at){
        return "阿根廷 " + label(at,ARGENTINA)
            + "\n北京 " + label(at,BEIJING)
            + "\n纽约 " + label(at,NEW_YORK);
    }
    public static Instant fundingOnArgentinaDate(LocalDate day,int hour){
        if(hour!=5 && hour!=13 && hour!=21) throw new IllegalArgumentException("Expected 05:00/13:00/21:00 Argentina");
        return day.atTime(hour,0).atZone(ARGENTINA).toInstant();
    }
    public static Instant reminderAt(Instant event,int minutesBefore){
        if(minutesBefore!=15 && minutesBefore!=30)throw new IllegalArgumentException("Only 15 or 30 minutes");
        return event.minus(Duration.ofMinutes(minutesBefore));
    }
}
