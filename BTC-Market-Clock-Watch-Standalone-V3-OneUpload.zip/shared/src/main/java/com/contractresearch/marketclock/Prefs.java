package com.contractresearch.marketclock;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import java.time.Instant;

public final class Prefs {
    private Prefs() {}
    private static final String FILE="market_clock_v1";
    public static SharedPreferences get(Context c) { return c.getSharedPreferences(FILE,Context.MODE_PRIVATE); }
    public static int lead(Context c) { int n=get(c).getInt("lead",15); return n==30?30:15; }
    /** Separate lead time for every event category. Missing overrides inherit the global default. */
    public static int lead(Context c,String type) {
        int n=get(c).getInt("lead_"+type,lead(c));
        return n==30?30:15;
    }
    /** The three fixed 8-hour settlements each have their own reminder lead. */
    public static int lead(Context c,String type,Instant eventAt) {
        if("funding".equals(type)) {
            int hour=eventAt.atZone(ClockZones.ARGENTINA).getHour();
            if(hour==5 || hour==13 || hour==21) {
                String key="funding_"+String.format(java.util.Locale.US,"%02d",hour);
                int n=get(c).getInt("lead_"+key,lead(c,"funding"));
                return n==30?30:15;
            }
        }
        return lead(c,type);
    }
    public static boolean enabled(Context c,String type) {
        if (type.equals("funding")) return get(c).getBoolean("funding",true);
        if (type.startsWith("nyse")) return get(c).getBoolean(type, true);
        if (type.equals("expiry")) return get(c).getBoolean("expiry",true);
        if (type.equals("fomc") || type.equals("cpi") || type.equals("nfp") || type.equals("pce")) return get(c).getBoolean(type,true);
        if (type.equals("ppi") || type.equals("gdp")) return get(c).getBoolean(type,false);
        return false;
    }
    public static boolean isWatch(Context c) { return c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_WATCH); }
    public static boolean notificationsEnabled(Context c) { return get(c).getBoolean("notify_here",true); }
    /** Apply one lead-time preset to all event categories. */
    public static void setLead(Context c,int n) {
        int minutes=n==30?30:15;
        SharedPreferences.Editor editor=get(c).edit().putInt("lead",minutes);
        for(String key:leadKeys())editor.putInt("lead_"+key,minutes);
        editor.apply();
    }
    public static void setTypeLead(Context c,String type,int n) {
        get(c).edit().putInt("lead_"+type,n==30?30:15).apply();
    }
    public static void setEnabled(Context c,String key,boolean value) { get(c).edit().putBoolean(key,value).apply(); }
    public static String[] settingsKeys() { return new String[]{"funding","nyse_open","nyse_afternoon","nyse_close","nyse_pre","expiry","fomc","cpi","nfp","pce","ppi","gdp"}; }
    public static String[] leadKeys() { return new String[]{"funding","funding_05","funding_13","funding_21","nyse_open","nyse_afternoon","nyse_close","nyse_pre","expiry","fomc","cpi","nfp","pce","ppi","gdp"}; }
}
