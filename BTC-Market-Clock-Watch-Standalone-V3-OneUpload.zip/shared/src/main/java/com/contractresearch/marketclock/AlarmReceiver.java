package com.contractresearch.marketclock;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import java.time.Instant;

public class AlarmReceiver extends BroadcastReceiver {
    // New channel ID because Android will not overwrite existing channel sound/vibration.
    public static final String CHANNEL="market_alerts_v3";
    public static void ensureChannel(Context c){
        NotificationManager nm=c.getSystemService(NotificationManager.class);
        if(nm==null)return;
        NotificationChannel ch=new NotificationChannel(CHANNEL,"市场提醒（声音与振动）",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("资金费率、美股、宏观、期权及测试提醒");
        ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,400,200,400,200,650});
        ch.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
            new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        nm.createNotificationChannel(ch);
    }
    public static boolean channelReady(Context c){
        NotificationManager nm=c.getSystemService(NotificationManager.class);
        if(nm==null||!nm.areNotificationsEnabled())return false;
        NotificationChannel ch=nm.getNotificationChannel(CHANNEL);
        return ch!=null&&ch.getImportance()>=NotificationManager.IMPORTANCE_HIGH&&ch.shouldVibrate()&&ch.getSound()!=null;
    }
    @Override public void onReceive(Context c,Intent intent){
        if("renew".equals(intent.getAction())){Scheduler.plan(c);return;}
        String type=intent.getStringExtra("type");
        if(type==null)return;
        if(!type.equals("test") && (!Prefs.notificationsEnabled(c)||!Prefs.enabled(c,type)))return;
        if(Build.VERSION.SDK_INT>=33 && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        long at=intent.getLongExtra("at",System.currentTimeMillis());
        if(!type.equals("test") && System.currentTimeMillis()>at+30*60_000L)return; // allow a late notice, not stale alerts hours later
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null)return;
        ensureChannel(c);
        String title=intent.getStringExtra("title");if(title==null)title="BTC 时间提醒";
        String detail=intent.getStringExtra("detail");if(detail==null)detail="";
        int lead=Prefs.lead(c,type,Instant.ofEpochMilli(at));
        long remaining=at-System.currentTimeMillis();
        boolean late=remaining<(lead*60_000L-60_000L);
        String text=type.equals("test")?detail:((late?"补发提醒":"提前 "+lead+" 分钟")+" · "+detail
                +"\n阿根廷事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.ARGENTINA)
                +"\n阿根廷提醒 "+ClockZones.label(ClockZones.reminderAt(Instant.ofEpochMilli(at),lead),ClockZones.ARGENTINA)
                +"\n北京事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.BEIJING)
                +"\n纽约事件 "+ClockZones.label(Instant.ofEpochMilli(at),ClockZones.NEW_YORK));
        PendingIntent open=PendingIntent.getActivity(c,1,new Intent(c,MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(c,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(open).setAutoCancel(true).setLocalOnly(true)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setWhen(System.currentTimeMillis()).setShowWhen(true).build();
        String delivered="delivered:"+type+":"+at;
        if(!type.equals("test") && Prefs.get(c).contains(delivered))return;
        NotificationChannel channel=nm.getNotificationChannel(CHANNEL);
        if(!nm.areNotificationsEnabled() || channel==null || channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return;
        nm.notify((type+at).hashCode(),note);
        if(!type.equals("test"))Prefs.get(c).edit().putLong(delivered,at).apply();
    }
}
