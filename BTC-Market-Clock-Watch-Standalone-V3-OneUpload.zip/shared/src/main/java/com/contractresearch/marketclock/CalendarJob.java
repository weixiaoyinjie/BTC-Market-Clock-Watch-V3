package com.contractresearch.marketclock;

import android.app.job.JobParameters;
import android.app.job.JobService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CalendarJob extends JobService {
    private ExecutorService executor;
    @Override public boolean onStartJob(JobParameters params) {
        executor=Executors.newSingleThreadExecutor();
        executor.execute(()->{
            try{OfficialCalendars.refresh(getApplicationContext());}
            finally{jobFinished(params,false);}
        });
        return true;
    }
    @Override public boolean onStopJob(JobParameters params) {
        if(executor!=null)executor.shutdownNow();
        return true;
    }
}
